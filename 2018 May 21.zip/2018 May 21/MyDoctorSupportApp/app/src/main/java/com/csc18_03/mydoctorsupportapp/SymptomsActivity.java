package com.csc18_03.mydoctorsupportapp;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public class SymptomsActivity extends AppCompatActivity implements InterfaceSymptomsActivity {

    private static final String TAG = "SymptomsActivity";

    private ArrayList<Symptom> dictionaryWords;
    private ArrayList<Symptom> filteredList;
    private EditText searchBox;
    private SymptomAdapter adapter2;
    private RecyclerView symptomPickedRV;

    TextView numberOfSymptomPicked;
    private RecyclerView symptomRecyclerView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_symptoms_pick, menu);
        return true;
    }

    //method that takes up all tools or icons on the action bar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.iconDiagnose) {
            startDiagnosis();
        }
        return true;
    }

    //THIS METHOD IS USED DO MAKE COMMUNICATION TO THE SERVER BY SENDING THE PICKED SYMPTOMS
    private void startDiagnosis() {
        Toast.makeText(this, "Diagnosis Started ...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {

                Socket s = null;
                try {
                    s = new Socket("192.168.43.83", 4040);

                    DataInputStream in = new DataInputStream(s.getInputStream());
                    DataOutputStream out = new DataOutputStream(s.getOutputStream());

                    Gson gson = new Gson();
                    String jsonArrayString = gson.toJson(adapter.symptomPickedList);

                    out.writeUTF(jsonArrayString);
                    String data = in.readUTF();

                    Log.e(TAG, "run: " + data);

                } catch (UnknownHostException e) {
                    Log.e(TAG, "Sock:" + e.getMessage());
                } catch (EOFException e) {
                    Log.e(TAG, "EOF:" + e.getMessage());
                } catch (IOException e) {
                    Log.e(TAG, "IO:" + e.getMessage());
                } finally {
                    if (s != null) try {
                        s.close();
                    } catch (IOException e) {
                        Log.e(TAG, "close:" + e.getMessage());
                    }
                }
            }
        }).start();
    }

    SymptomPickedAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);


        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_white_24dp);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        //dictionaryWords = getAllSymptoms();
        filteredList = new ArrayList<Symptom>();
        //filteredList.addAll(dictionaryWords);

        searchBox = findViewById(R.id.search_box);
        numberOfSymptomPicked = findViewById(R.id.numberOfSymptomPicked);


        symptomPickedRV = findViewById(R.id.symptomPicked);
        adapter = new SymptomPickedAdapter(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        symptomPickedRV.setAdapter(adapter);
        symptomPickedRV.setLayoutManager(layoutManager);

        //ADD PICKED SYMPTOMS
        /*adapter.addSymptomPicked(new SymptomPicked());
        adapter.addSymptomPicked(new SymptomPicked());
        adapter.addSymptomPicked(new SymptomPicked());
        adapter.addSymptomPicked(new SymptomPicked());
        adapter.addSymptomPicked(new SymptomPicked());
        adapter.addSymptomPicked(new SymptomPicked());
        adapter.addSymptomPicked(new SymptomPicked());
        */


        //SYMPTOMS ADAPTER
        symptomRecyclerView = findViewById(R.id.symptomRecyclerView);


        LinearLayoutManager layoutManager2 = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        adapter2 = new SymptomAdapter(this, filteredList);
        symptomRecyclerView.setAdapter(adapter2);
        symptomRecyclerView.setLayoutManager(layoutManager2);


        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                adapter2.getmFilter().filter(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        //GET ALL SYMPTOMS FROM THE SERVER
        retrieveSymptoms();
    }

    private ArrayList<Symptom> getAllSymptoms(String response) {
        ArrayList<Symptom> data = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(response);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String symptom_name = jsonObject.getString("symptom_name");
                int symptom_id = jsonObject.getInt("symptom_id");
                data.add(new Symptom(symptom_id,symptom_name));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    @Override
    public void scrollSymptomPicked(int position) {
        symptomPickedRV.scrollToPosition(position);
    }

    @Override
    public void updateNumberOfSymptomPicked(int size) {
        numberOfSymptomPicked.setText(String.valueOf(size));
    }

    @Override
    public void clearSelectedSymptom() {
        searchBox.setText("");
    }


    public class SymptomAdapter extends RecyclerView.Adapter<SymptomAdapter.SymptomHolder> {

        Context context;
        ArrayList<Symptom> symptomList = new ArrayList<>();
        private SymptomAdapter.CustomFilter mFilter;


        public SymptomAdapter(Context context) {
            this.context = context;
        }

        public SymptomAdapter(Context context, ArrayList<Symptom> symptomList) {
            this.context = context;
            this.symptomList = symptomList;
            mFilter = new SymptomAdapter.CustomFilter(SymptomAdapter.this);
        }

        public void addSymptom(Symptom symptom) {
            symptomList.add(symptom);
            notifyItemInserted(symptomList.size() - 1);
        }

        public CustomFilter getmFilter() {
            return mFilter;
        }

        @Override
        public SymptomAdapter.SymptomHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new SymptomAdapter.SymptomHolder(LayoutInflater.from(context).inflate(R.layout.row_symptom, parent, false));
        }

        @Override
        public void onBindViewHolder(SymptomAdapter.SymptomHolder holder, int position) {
            Symptom symptom = symptomList.get(position);

            holder.symptomNameTextView.setText(symptom.symptomName);

        }

        @Override
        public int getItemCount() {
            return symptomList.size();
        }


        public class SymptomHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

            TextView symptomNameTextView;

            public SymptomHolder(View itemView) {
                super(itemView);
                symptomNameTextView = itemView.findViewById(R.id.symptomName);


                itemView.setOnClickListener(this);


            }

            @Override
            public String toString() {
                return super.toString() + " '" + symptomNameTextView.getText() + "'";
            }


            AlertDialog dialog;

            @Override
            public void onClick(View view) {
                final Symptom symptom = symptomList.get(getAdapterPosition());

                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                View view1 = LayoutInflater.from(context).inflate(R.layout.dialog_symptom_picked_level, null, false);

                TextView level_low = view1.findViewById(R.id.level_low);
                TextView level_medium = view1.findViewById(R.id.level_medium);
                TextView level_high = view1.findViewById(R.id.level_high);

                level_low.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        adapter.addSymptomPicked(new SymptomPicked(symptom.symptomId,symptom.symptomName, "low"));
                        dialog.dismiss();
                    }
                });
                level_medium.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        adapter.addSymptomPicked(new SymptomPicked(symptom.symptomId,symptom.symptomName, "Moderate"));
                        dialog.dismiss();
                    }
                });
                level_high.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        adapter.addSymptomPicked(new SymptomPicked(symptom.symptomId,symptom.symptomName, "Severe"));
                        dialog.dismiss();
                    }
                });


                builder.setView(view1);
                builder.setNegativeButton("Cancel", null);
                dialog = builder.create();
                dialog.show();


            }
        }


        public class CustomFilter extends Filter {


            private SymptomAdapter mAdapter;

            private CustomFilter(SymptomAdapter mAdapter) {
                super();
                this.mAdapter = mAdapter;
            }

            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                filteredList.clear();
                final FilterResults results = new FilterResults();
                if (constraint.length() == 0) {
                    filteredList.addAll(dictionaryWords);
                } else {
                    final String filterPattern = constraint.toString().toLowerCase().trim();
                    for (final Symptom mWords : dictionaryWords) {
                        if (mWords.symptomName.toLowerCase().startsWith(filterPattern)) {
                            filteredList.add(mWords);
                        }
                    }
                }
                System.out.println("Count Number " + filteredList.size());
                results.values = filteredList;
                results.count = filteredList.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                System.out.println("Count Number 2 " + ((List<Symptom>) results.values).size());
                this.mAdapter.notifyDataSetChanged();
            }

        }
    }


    public void retrieveSymptoms() {
        Toast.makeText(this, "Connecting ...", Toast.LENGTH_SHORT).show();
        
        String url = "http://192.168.43.83/MyDoctorSupportWeb/getSymptomsAll.php";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dictionaryWords = getAllSymptoms(response);
                filteredList = new ArrayList<Symptom>();
                filteredList.addAll(dictionaryWords);

                adapter2 = new SymptomAdapter(SymptomsActivity.this, filteredList);
                symptomRecyclerView.setAdapter(adapter2);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(SymptomsActivity.this, "Failed to connect !!!", Toast.LENGTH_SHORT).show();
            }
        });
        requestQueue.add(stringRequest);

    }

}

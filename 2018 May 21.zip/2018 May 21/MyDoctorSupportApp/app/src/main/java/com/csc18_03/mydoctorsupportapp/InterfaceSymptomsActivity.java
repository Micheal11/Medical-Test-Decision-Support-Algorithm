package com.csc18_03.mydoctorsupportapp;

/**
 * Created by Admin on 4/28/2018.
 */

public interface InterfaceSymptomsActivity {
    void scrollSymptomPicked(int position);
    void updateNumberOfSymptomPicked(int size);
    void clearSelectedSymptom();
}

package com.csc18_03.mydoctorsupportapp;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SymptomPickedAdapter extends RecyclerView.Adapter<SymptomPickedAdapter.SymptomPickedHolder> {

    Context context;
    ArrayList<SymptomPicked> symptomPickedList = new ArrayList<>();

    public SymptomPickedAdapter(Context context) {
        this.context = context;
    }

    public void addSymptomPicked(SymptomPicked symptomPicked) {
        if (isAlreadyAdded(symptomPicked)) {
            Toast toast = Toast.makeText(context,"Symptom Already Picked", Toast.LENGTH_SHORT);
            TextView v = toast.getView().findViewById(android.R.id.message);
            v.setTextColor(Color.parseColor("#ef5350"));
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        } else {
            symptomPickedList.add(symptomPicked);
            notifyItemInserted(symptomPickedList.size() - 1);
            ((InterfaceSymptomsActivity) context).clearSelectedSymptom();
            ((InterfaceSymptomsActivity) context).scrollSymptomPicked(symptomPickedList.size() - 1);
            ((InterfaceSymptomsActivity) context).updateNumberOfSymptomPicked(symptomPickedList.size());
        }
    }

    private boolean isAlreadyAdded(SymptomPicked symptomPicked) {

        for (SymptomPicked picked : symptomPickedList) {
            if (picked.symptomName == symptomPicked.symptomName) {
                return true;

            }
        }

        return false;
    }


    @Override
    public SymptomPickedHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new SymptomPickedHolder(LayoutInflater.from(context).inflate(R.layout.row_symptom_picked, parent, false));
    }

    @Override
    public void onBindViewHolder(SymptomPickedHolder holder, int position) {
        SymptomPicked symptomPicked = symptomPickedList.get(position);

        holder.symptomName.setText(symptomPicked.symptomName);
        holder.level.setText(symptomPicked.symptomLevel);

        switch (symptomPicked.symptomLevel.trim().toLowerCase()){
            case "low":
                holder.level.setTextColor(Color.GREEN);
                break;
            case "moderate":
                holder.level.setTextColor(Color.parseColor("#ffa726"));
                break;
            case "severe":
                holder.level.setTextColor(Color.RED);
                break;
        }





    }

    @Override
    public int getItemCount() {
        return symptomPickedList.size();
    }

    public class SymptomPickedHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView symptomName;
        TextView level;
        ImageView delete;
        ImageView edit;

        public SymptomPickedHolder(View itemView) {
            super(itemView);
            symptomName = itemView.findViewById(R.id.symptomName);
            delete = itemView.findViewById(R.id.delete);
            edit = itemView.findViewById(R.id.edit);
            level = itemView.findViewById(R.id.level);

            delete.setOnClickListener(this);
            edit.setOnClickListener(this);
        }

        AlertDialog dialog;

        @Override
        public void onClick(View view) {
            switch (view.getId()){
                case R.id.delete:
                    int p = getAdapterPosition();
                    symptomPickedList.remove(p);
                    notifyItemRemoved(p);
                    ((InterfaceSymptomsActivity) context).updateNumberOfSymptomPicked(symptomPickedList.size());
                    break;
                case R.id.edit:
                    //EDIT THE SAVED SYMPTOM


                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    View view1 = LayoutInflater.from(context).inflate(R.layout.dialog_symptom_picked_level,null,false);

                    TextView level_low = view1.findViewById(R.id.level_low);
                    TextView level_medium =  view1.findViewById(R.id.level_medium);
                    TextView level_high =  view1.findViewById(R.id.level_high);

                    level_low.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            symptomPickedList.get(getAdapterPosition()).symptomLevel="low";
                            notifyItemChanged(getAdapterPosition());
                            dialog.dismiss();
                        }
                    });
                    level_medium.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            symptomPickedList.get(getAdapterPosition()).symptomLevel="Moderate";
                            notifyItemChanged(getAdapterPosition());
                            dialog.dismiss();
                        }
                    });
                    level_high.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            symptomPickedList.get(getAdapterPosition()).symptomLevel="Severe";
                            notifyItemChanged(getAdapterPosition());
                            dialog.dismiss();
                        }
                    });


                    builder.setView(view1);
                    builder.setNegativeButton("Cancel",null);
                    dialog = builder.create();
                    dialog.show();




                    break;
            }
        }
    }
}

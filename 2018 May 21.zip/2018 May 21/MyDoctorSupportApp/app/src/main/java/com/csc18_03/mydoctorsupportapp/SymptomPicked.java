package com.csc18_03.mydoctorsupportapp;


public class SymptomPicked {
    
    int symptomId;
    String symptomName;
    String symptomLevel;

    public SymptomPicked(int symptomId, String symptomName, String symptomLevel) {
        this.symptomId = symptomId;
        this.symptomName = symptomName;
        this.symptomLevel = symptomLevel;
    }
}

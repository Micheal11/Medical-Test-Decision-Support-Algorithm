package com.csc18_03.mydoctorsupportapp;

/**
 * Created by Admin on 4/9/2018.
 */

public class Symptom {
    int symptomId;
    String symptomName;

    public Symptom(int symptomId, String symptomName) {
        this.symptomId = symptomId;
        this.symptomName = symptomName;
    }
}

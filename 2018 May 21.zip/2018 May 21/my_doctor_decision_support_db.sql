-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2018 at 03:57 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_doctor_decision_support_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `disease`
--

CREATE TABLE `disease` (
  `disease_id` int(10) NOT NULL,
  `disease_name` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `disease`
--

INSERT INTO `disease` (`disease_id`, `disease_name`) VALUES
(1, 'Malaria'),
(2, 'Flue'),
(3, 'Tuberclosis'),
(4, 'Measles');

-- --------------------------------------------------------

--
-- Table structure for table `disease_symptom_priority`
--

CREATE TABLE `disease_symptom_priority` (
  `priority_id` int(10) NOT NULL,
  `disease_id` int(10) NOT NULL,
  `symptom_id` int(10) NOT NULL,
  `priority` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `disease_symptom_priority`
--

INSERT INTO `disease_symptom_priority` (`priority_id`, `disease_id`, `symptom_id`, `priority`) VALUES
(43, 3, 4, 5),
(42, 3, 13, 10),
(41, 3, 14, 15),
(40, 3, 3, 18),
(39, 1, 5, 16),
(38, 1, 13, 16),
(37, 1, 12, 12),
(36, 1, 1, 14),
(35, 1, 6, 8),
(34, 1, 11, 17),
(33, 1, 2, 18),
(32, 4, 11, 14),
(31, 4, 10, 12),
(30, 4, 9, 17),
(29, 4, 8, 19),
(28, 4, 7, 17),
(27, 2, 6, 14),
(26, 2, 4, 18),
(25, 2, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `symptom`
--

CREATE TABLE `symptom` (
  `symptom_id` int(10) NOT NULL,
  `symptom_name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symptom`
--

INSERT INTO `symptom` (`symptom_id`, `symptom_name`) VALUES
(1, 'vomiting'),
(2, 'high body temperature'),
(3, 'cough'),
(4, 'runnning nose'),
(5, 'weakness'),
(6, 'head ache'),
(7, 'body aches'),
(8, 'reddish brown rash'),
(9, 'itchy skin'),
(10, 'watery eyes'),
(11, 'fever'),
(12, 'diarrhea'),
(13, 'loss of appetite'),
(14, 'dry throat');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `disease`
--
ALTER TABLE `disease`
  ADD PRIMARY KEY (`disease_id`),
  ADD UNIQUE KEY `disease_name` (`disease_name`);

--
-- Indexes for table `disease_symptom_priority`
--
ALTER TABLE `disease_symptom_priority`
  ADD PRIMARY KEY (`priority_id`);

--
-- Indexes for table `symptom`
--
ALTER TABLE `symptom`
  ADD PRIMARY KEY (`symptom_id`),
  ADD UNIQUE KEY `symptom_name` (`symptom_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `disease`
--
ALTER TABLE `disease`
  MODIFY `disease_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `disease_symptom_priority`
--
ALTER TABLE `disease_symptom_priority`
  MODIFY `priority_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `symptom`
--
ALTER TABLE `symptom`
  MODIFY `symptom_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

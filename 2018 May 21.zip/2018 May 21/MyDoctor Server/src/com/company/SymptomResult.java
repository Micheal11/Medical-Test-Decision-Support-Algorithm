package com.company;

/**
 * Created by Admin on 5/21/2018.
 */
public class SymptomResult {
    int symptomID;
    int diseaseID;
    int symptomPriority;
    int total;
    int percentage;

    public SymptomResult(int symptomID, int diseaseID, int symptomPriority, int total, int percentage) {
        this.symptomID = symptomID;
        this.diseaseID = diseaseID;
        this.symptomPriority = symptomPriority;
        this.total = total;
        this.percentage = percentage;
    }

    @Override
    public String toString() {
        return "SID-"+symptomID+" : "+"DID-"+diseaseID+" : "+"%-"+percentage;
    }
}

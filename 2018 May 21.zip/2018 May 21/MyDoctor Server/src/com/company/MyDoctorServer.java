package com.company;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.*;
import java.util.*;

public class MyDoctorServer extends Thread {

    public static final int PORT_NUMBER = 4040;
    protected Socket socket;

    private MyDoctorServer(Socket socket) {
        this.socket = socket;
        System.out.println("New client connected from " + socket.getInetAddress().getHostAddress());
        start();
    }

    public void run() {

        DataInputStream in;
        DataOutputStream out;

        try {
            in = new DataInputStream(socket.getInputStream());
            out = new DataOutputStream(socket.getOutputStream());

            String clientMsg;
            String serverMsg = null;

            while ((clientMsg = in.readUTF()) != null) {
                System.out.println("Message received:" + clientMsg);
                processClientMessage(clientMsg);
                out.writeUTF(clientMsg);
            }

        } catch (IOException ex) {
            System.out.println("Unable to get streams from client");
        } finally {
            try {
                socket.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }


    ArrayList<SymptomResult> symptomResultArrayList = new ArrayList<>();
    ArrayList<SymptomResult> finalResultsList  = new ArrayList<>();

    private void processClientMessage(String clientMsg) {
        symptomResultArrayList.clear();
        finalResultsList.clear();

        ArrayList<Integer> arrayListSymptoms = new ArrayList<>();  //symptoms
        ArrayList<Integer> arrayListOccurrence = new ArrayList<>();  //occurrence


        try {
            JSONArray jsonArray = new JSONArray(clientMsg);
            for (int i = 0; i < jsonArray.length(); i++) {     //PASSES THRU THE SYMPTOMS SENT FROM THE APP
                JSONObject jsonObject = jsonArray.getJSONObject(i);     // PICKS ONE SYMPTOM AT A TIME

                //symptom occurrences in a disease
                int symptomId = jsonObject.getInt("symptomId");
                System.out.println("Symptom ID : " + symptomId);
                int symptomOccurrence = getDiseasesWithSymptom(symptomId);

                arrayListSymptoms.add(symptomId);
                arrayListOccurrence.add(symptomOccurrence);

            }

            /////////////////////////

            ArrayList<Integer> copyOccurrence =new ArrayList<>();
            for (Integer integer : arrayListOccurrence) {
                copyOccurrence.add(integer);
            }
            Collections.sort(copyOccurrence, new Comparator<Integer>() {
                @Override
                public int compare(Integer o1, Integer o2) {
                    return o1-o2;
                }
            });
            Set<Integer> copySet = new LinkedHashSet<>(copyOccurrence);   //A SET CONTAIN NONE REPEATED SYMPTOM OCCURRENCES

            ///////System.out.println(copyOccurrence);
            ///////System.out.println(arrayListOccurrence);

            ArrayList<SymptomResult> someBigList = new ArrayList<>();

            for (Integer j : copySet)                                       //GOES THRU THE NONE REPEATED SYMPTOM OCCURRENCES
                for (int i = 0; i < arrayListOccurrence.size(); i++) {      //GOES THRU ALL THE OCCURRENCES (unsorted/original)

                int occurrence = arrayListOccurrence.get(i);
                if (occurrence == j) {
                    int symptomId = arrayListSymptoms.get(i);
                    ArrayList<SymptomResult> smallList = getSymptomResultWithSymptomID(symptomId);
                    for (SymptomResult symptomResult : smallList) someBigList.add(symptomResult);
                }
            }


            ////////////////System.out.println(someBigList);

            Collections.sort(someBigList, new Comparator<SymptomResult>() {
                @Override
                public int compare(SymptomResult o1, SymptomResult o2) { return o2.percentage - o1.percentage;
                }
            });
            System.out.println(someBigList);

            for (SymptomResult symptomResult : someBigList) {
                finalResultsList.add(symptomResult);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private ArrayList<SymptomResult> getSymptomResultWithSymptomID(int symptomId) {
        ArrayList<SymptomResult> list = new ArrayList<>();
        for (int i = 0; i < symptomResultArrayList.size(); i++) {
            SymptomResult symptomResult = symptomResultArrayList.get(i);
            if (symptomResult.symptomID == symptomId) {
                list.add(symptomResult);
            }
        }
        return list;
    }

    private int getDiseasesWithSymptom(int symptom_id) throws SQLException {
        ResultSet resultsDisease = executeSqlStatement("select * from disease_symptom_priority where symptom_id = '" + symptom_id + "'");

        int diseaseCount = 0;


        while (resultsDisease.next()) {
            int disease_id = resultsDisease.getInt(2);
            int symptom_priority = resultsDisease.getInt(4);
            int total_priority = getTotalPriorityForDisease(disease_id);
            int percentage = ((symptom_priority * 100) / total_priority);


//            System.out.println("Symptom ID is :"+ symptom_id);

            System.out.println("DISEASE ID : " + disease_id + " SYMPTOM PRIORITY : " + symptom_priority + " TOTAL : " + total_priority + " PERCENTAGE : " + percentage);
            SymptomResult symptomResult = new SymptomResult(symptom_id, disease_id, symptom_priority, total_priority, percentage);
            symptomResultArrayList.add(symptomResult);
            diseaseCount++;
        }

        System.out.println("Disease counted are: " + diseaseCount);

        return diseaseCount;
    }

    private int getTotalPriorityForDisease(int disease_id) throws SQLException {
        int total = 0;

        ResultSet allPriorities = executeSqlStatement("select priority from disease_symptom_priority where disease_id = '" + disease_id + "'");
        while (allPriorities.next()) {
            int priority = allPriorities.getInt(1);
            total = total + priority;
        }
        return total;
    }


    //THIS METHOD EXECUTES AN SQL STATEMENT AND BRINGS BACK THE RESULTS (ROWS) AS A RESULT_SET OBJECT
    public ResultSet executeSqlStatement(String sqlStatement) {
        ResultSet resultSet = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_doctor_decision_support_db", "root", "");
            Statement statement = connection.createStatement();
            resultSet = statement.executeQuery(sqlStatement);
            //connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultSet;
    }


    public void xxx() {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_doctor_decision_support_db", "root", "");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from symptom");
            while (resultSet.next()) {
                System.out.println(
                        resultSet.getString(1) + "" +
                                resultSet.getString(2) + "");
            }
            connection.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

        System.out.println(">> Server Started ...");
        ServerSocket server = null;

        try {
            server = new ServerSocket(PORT_NUMBER);
            while (true) {
                Socket s = server.accept();
                new MyDoctorServer(s);
            }
        } catch (IOException ex) {
            System.out.println("Unable to start server.");
        } finally {
            try {
                if (server != null)
                    server.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        System.out.println(">> Server Ended");

    }
}
